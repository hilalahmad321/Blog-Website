<?php

namespace App\Http\Controllers;

use App\Models\admin;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    // load Admin Login
    public function index(){
        return view('admin.login');
    }
    public function submit_login(Request $req){
        $req->validate([
            'username'=>'required',
            'passwrd'=>'required'
        ]);

        $checkAdmin=admin::where(['username'=>$req->username,'passwrd'=>$req->passwrd])->count();
        if($checkAdmin>0){
            $adminData=admin::where(['username'=>$req->username,'passwrd'=>$req->passwrd])->first();
            session(['adminData'=>$adminData]);
            $req->session()->flash('succes','You have Logined');
            echo "<script>alert('You have login')</script>";
            return redirect('admin/dashboard');
        }
        else{
            $req->session()->flash('error','Invalid username password');
            return redirect('admin/login')->with('error','Invalid UserName and Password');
        }
    }



    // Dashborad 
    public function dashboard(){
        return view('admin.dashboard');
    }

    // Logout
    public function logout(){
        session()->forget(['adminData']);
        return redirect('admin/login');
    }
}
