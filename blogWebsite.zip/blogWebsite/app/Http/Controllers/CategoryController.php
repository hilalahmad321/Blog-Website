<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    // load Category
    public function index(){
        $data['total']=category::get();
        $data['categorys']=category::orderBy('cat_id','DESC')->paginate(4);
        return view('admin.category',$data);
    }
    public function addCategory(Request $req){
        $category= new category;
        $req->validate([
            'cat_name'=>'required',
        ]);
        $category->cat_name=$req->cat_name;
        $category->save();

        $req->session()->flash('success','category Add Successfully');
        return redirect('admin/category');
    }
    // public function searchCategory(Request $req){
    //     $search=$req->input('search');
    //     $data['category']=category::paginate(3)
    //                     ->where('cat_name','LIKE','%'.$search.'%');
    //     return view('admin.search',$data);
    // }

    public function deleteCategory($cat_id){
        // echo $id;
        $category=category::where('cat_id',$cat_id);
        $category->delete();
        return redirect('admin/category')->with('delete','Category Delete Successfully');
    }

    public function updateCategory($cat_id){
        $category['single']=category::where('cat_id',$cat_id)->first();
        return view('admin.update-category',$category);
    }
    public function saveUpdateCat(Request $req, $cat_id){
        $category=new category;
        $req->validate([
            'cat_name'=>'required',
        ]);
        $category=category::where('cat_id',$cat_id)->update(array(
            "cat_name"=>$req->cat_name
        ));
        // $category->update();
        $req->session()->flash('success','category Update Successfully');
        return redirect('admin/category');
    }
}
