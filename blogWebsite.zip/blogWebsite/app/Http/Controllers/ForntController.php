<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\comment;
use App\Models\post;
use Illuminate\Http\Request;

class ForntController extends Controller
{
    //load fontpage
    public function index(){
        $post['posts']=post::paginate(3);
        return view('fortend.index',$post);
    }
    public function articales(){
        $data['categorys']=category::all();
        $data['posts']=post::paginate(9);
        return view('fortend.articales',$data);
    }
    public function articale(Request $req,$cat_id){
        $data['categorys']=category::get();
        $data['posts']=post::where('cat_id',$cat_id)->get();
        return view('fortend.category',$data);
    }

    public function singlePost($post_id){
        post::where('post_id',$post_id)->increment('views');
            $data['limitpost']=post::orderBy('post_id','DESC')->limit(5)->get();
            $data['posts']=post::where('post_id',$post_id)->get();
            $data['comments']=comment::where('post_id',$post_id)->join('users','comments.user_id','=','users.id')->orderBy('comment_id','DESC')->get();
            return view('fortend.singlePost',$data);
    }

    public function save_comment(Request $req,$post_id){
        $comment=new comment;
        $req->validate([
            'comments'=>'required',
        ]);
        $comment->user_id=$req->user()->id;
        $comment->post_id=$post_id;
        $comment->comments=$req->comments;
        $comment->save();

        return redirect('singlePost/'.$post_id);

    }
}

