<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    //load Post
    public function index(){
        $data['category']=category::all();
        $data['total']=post::all();
        $data['posts']=post::orderBy('post_id','DESC')->paginate(3);
        return view('admin.post',$data);
    }
    public function addPost(Request $req ){
        $post=new post;
        $req->validate([
            'title'=>'required',
            'cat_id'=>'required',
            'thumb'=>'required',
            'full_img'=>'required',
            'detail'=>'required',
            'tags'=>'required',
        ]);
        if($req->hasFile('thumb')){
          $file_name_thumb=$req->file('thumb');
          $new_name_thumb=rand().'.'.$file_name_thumb->getClientOriginalExtension();
          $dest1=public_path('/imgs');
          $file_name_thumb->move($dest1,$new_name_thumb);
        }else{
            $new_name_thumb='na';
        }

        if($req->hasFile('full_img')){
            $file_name_full_img=$req->file('full_img');
            $new_name_full_img=rand().'.'.$file_name_full_img->getClientOriginalExtension();
            $dest2=public_path('/imgs');
            $file_name_full_img->move($dest2,$new_name_full_img);
        }
        else{
            $new_name_full_img='na';
        }
        $post->user_id='1';
        $post->cat_id=$req->cat_id;
        $post->title=$req->title;
        $post->thumb=$new_name_thumb;
        $post->full_img=$new_name_full_img;
        $post->detail=$req->detail;
        $post->tags=$req->tags;
        $post->save();
        $req->session()->flash('success','Post Add Successfully');
        return redirect('admin/post');
    }

    public function deletePost($post_id){
        // echo $post_id;
        // dd($post_id);
        $post=post::where(['post_id'=>$post_id]);
        // echo $post;
        // $img_path=public_path('imgs/'.$post->full_img);
        // if(post::exists($img_path)){
        //     unlink($img_path);
        // }
        $post->delete();
        return redirect('admin/post')->with('delete','Post Delete Successfully');
    }
    public function editpost($post_id){
        // echo $post_id;
        $post['category']=category::all();
        $post['single']=post::where(['post_id'=>$post_id])->get();
        return view('admin.update-post',$post);
    }
    public function saveupdatepost(Request $req, $post_id){
        $post=new post;
        $req->validate([
            'title'=>'required',
            'cat_id'=>'required',
            'thumb'=>'required',
            'full_img'=>'required',
            'detail'=>'required',
            'tags'=>'required',
        ]);
        if($req->hasFile('thumb')){
            $file_name_thumb=$req->file('thumb');
            $new_name_thumb=rand().'.'.$file_name_thumb->getClientOriginalExtension();
            $dest1=public_path('/imgs');
            $file_name_thumb->move($dest1,$new_name_thumb);
        }
        else{
            $new_name_thumb=$req->thumb;
        }
        if($req->hasFile('full_img')){
            $file_name_full_img=$req->file('full_img');
            $new_name_full_img=rand().'.'.$file_name_full_img->getClientOriginalExtension();
            $dest2=public_path('/imgs');
            $file_name_full_img->move($dest2,$new_name_full_img);
        }
        else{
            $new_name_full_img=$req->full_img;
        }
        post::where('post_id',$post_id)->update(array(
            "cat_id"=>$req->cat_id,
            "title"=>$req->title,
            "thumb"=>$new_name_thumb,
            "full_img"=>$new_name_full_img,
            "detail"=>$req->detail,
            "tags"=>$req->tags,
        ));
      
        // $post->update();

        // dd($req);
        $req->session()->flash('success','Post Update Successfully');
        return redirect('admin/post');

    }
}
