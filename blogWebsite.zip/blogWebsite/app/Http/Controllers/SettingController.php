<?php

namespace App\Http\Controllers;

use App\Models\setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    //
    public function index(){
        $data['settings']=setting::get();
        return view('admin.setting',$data);
    }
    public function saveupdate(Request $req,$id){
        $setting=new setting;

        if($req->hasFile('bg_img')){
            $bg_img=$req->file('bg_img');
            $dest=public_path('imgs/');
            $bg_img->move($dest,$bg_img);
        }
        else{
            $bg_img=$req->bg_img;
        }

        setting::where('setting_id',$id)->update([
            "bg_img"=>$bg_img,
            "logo_name"=>$req->logo_name
        ]);

        return redirect('admin/setting/'.$id);
    }
}
