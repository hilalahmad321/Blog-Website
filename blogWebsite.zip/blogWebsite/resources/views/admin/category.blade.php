@include('admin/header')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            Category \ View
        </div>
    </div>
</div>
@if (Session::has('success'))
<div class="container">
    <div class="w3-panel w3-green w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Success!</h3>
        <p>{{session('success')}}</p>
      </div>
</div>
@endif
@if (Session::has('delete'))
<div class="container">
    <div class="w3-panel w3-yellow w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Warning!</h3>
        <p>{{session('delete')}}</p>
      </div>
</div>
@endif

<div class="container mt-3">
    <div class="card p-3">
        <div >
            Category ( {{count($total)}} )
            <button class="w3-right btn w3-blue" onclick="document.getElementById('id01').style.display='block'">Add Category</button>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content w3-animate-right">
                    <form action="addCategory" class="p-5" method="post">
                        @csrf
                        <span onclick="document.getElementById('id01').style.display='none'" class="w3-display-topright btn w3-red mt-2 mr-2">X</span>
                        <h1>Add Category</h1>
                        <div class="form-group">
                            <label for="">Enter Category Name</label>
                            <input type="text" name="cat_name" id="" class="form-control">
                            @error('cat_name')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <button class="btn w3-blue" type="submit">Add Category</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">
    <div class="w3-bar">
      <form action="search" method="POST">
        <input type="text" name="search" id="" class="form-control w3-bar-item w3-border">
        <button type="submit" class="btn w3-yellow ml-2 w3-bar-item">Search</button>
      </form>
    </div>
</div>

<div class="container mt-5">
    <table class="w3-table-all">
        <tr>
            <th>Category Id</th>
            <th>Category Name</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($categorys as $cat)
            <tr>
                <td>{{$cat['cat_id']}}</td>
                <td>{{$cat['cat_name']}}</td>
                <td><a href="{{'edit/'.$cat['cat_id']}}" class="btn w3-green">Edit</a></td>
                <td><a href="{{'delete/'.$cat['cat_id']}}" onclick="return confirm('Are You Sure You want To delete this data')" class="btn w3-red">Delete</a></td>
            </tr>
        @endforeach
    </table>
</div>
<div class="container mt-3" style="margin: 0px 40%">
    {{$categorys->links()}}

</div>
@include('admin/footer')