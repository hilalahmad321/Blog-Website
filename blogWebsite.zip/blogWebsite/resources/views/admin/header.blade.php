
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/w3.css')}}">
    <title>Admin | Pannel</title>
</head>
<body>
    <div class="w3-sidebar w3-bar-block w3-animate-left w3-black" style="display:none;z-index:5" id="mySidebar">
        <button class=" w3-display-topright btn w3-red mt-3 mr-2 mb-5 w3-large " onclick="w3_close()">&times;</button>
        <a href="#" class="w3-bar-item  mt-5">Dashboard</a>
        <a href="category" class="w3-bar-item ">Category</a>
        <a href="post" class="w3-bar-item ">Post</a>
        <a href="setting" class="w3-bar-item ">Setting</a>
        @if (!Session::has('adminData'))
          <script>
              window.location.href=('login');
          </script>
        @endif
      </div>
      <div class="w3-overlay w3-animate-opacity " onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>
      <div class="w3-black">
       <div class="w3-container">
        <button class="btn w3-xxlarge w3-text-white" onclick="w3_open()">&#9776;</button>
        <span class="w3-xlarge mt-3">Blog Website</span>
        <a href="logout" class="w3-xlarge w3-right mt-3">Logout</a>
       </div>
        </div>
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->