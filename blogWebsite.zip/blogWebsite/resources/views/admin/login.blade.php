<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/w3.css')}}">
    <title>Admin | Login</title>
</head>
<style>
    body{
        background-color: crimson
    }
</style>
@if (Session::has('adminData'))
<script>
    window.location.href=('dashboard');
</script>
@endif
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 w3-content mt-5">
                <div class="w3-card-4 p-4 w3-round-xlarge w3-blue mt-5">
                   
                    <form action="login" method="POST">
                        @csrf
                        <h1>Admin Login</h1>
                        @if ($errors->any())
                        @foreach ($errors->all() as $err)
                            <p class="w3-text-red w3-xlarge">{{$err}}</p>
                        @endforeach
                    @endif
                    @if (Session::has('error'))
                        <p class="w3-text-red">{{session('error')}}</p>
                    @endif
                        <div class="form-group">
                            <label for=""><b> Enter User Name</b></label>
                            <input type="text" name="username" id="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for=""><b> Enter Password</b></label>
                            <input type="text" name="passwrd" id="" class="form-control">
                        </div>
                        <button class="btn w3-green" type="submit">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>