@include('admin/header')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            Post \ View
        </div>
    </div>
</div>
@if (Session::has('success'))
<div class="container">
    <div class="w3-panel w3-green w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Success!</h3>
        <p>{{session('success')}}</p>
      </div>
</div>
@endif
@if (Session::has('delete'))
<div class="container">
    <div class="w3-panel w3-yellow w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Warning!</h3>
        <p>{{session('delete')}}</p>
      </div>
</div>
@endif

<div class="container mt-3">
    <div class="card p-3">
        <div >
            Category ( {{count($total)}} )
            <button class="w3-right btn w3-blue" onclick="document.getElementById('id01').style.display='block'">Add Post</button>
        </div>
    </div>
</div>
<div class="container" style="z-index:10;">
    <div class="row">
        <div class="col-md-6">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content w3-animate-right">
                    <form action="addPost" class="p-5" method="post" enctype="multipart/form-data">
                        @csrf
                        <span onclick="document.getElementById('id01').style.display='none'" class="w3-display-topright btn w3-red mt-2 mr-2">X</span>
                        <h1>Add Post</h1>
                        <div class="form-group">
                            <label for="">Enter Post Title</label>
                            <input type="text" name="title" id="" class="form-control">
                            @error('title')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Enter Category</label>
                           <select name="cat_id" class="form-control" id="">
                               <option value="" disabled selected>----Select Any Category----</option>
                               @foreach ($category as $cat)
                                   <option value="{{$cat['cat_id']}}">{{$cat['cat_name']}}</option>
                               @endforeach
                           </select>
                           @error('cat_id')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Enter Thumb</label>
                            <input type="file" name="thumb" id="" class="form-control">
                            @error('thumb')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Enter Full Image</label>
                            <input type="file" name="full_img" id="" class="form-control">
                            @error('full_img')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Enter Detial</label>
                            <textarea name="detail" class="form-control" id="" cols="30" rows="10"></textarea>
                            @error('detail')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror

                        </div>
                        <div class="form-group">
                            <label for="">Enter Tags</label>
                            <textarea name="tags" class="form-control" id="" cols="30" rows="4"></textarea>
                            @error('tags')
                               <p class="w3-text-red">{{$message}}</p> 
                            @enderror
                        </div>
                        <button class="btn w3-blue" type="submit">Add Post</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">
    <div class="w3-bar">
      <form action="search" method="POST">
        <input type="text" name="search" id="" class="form-control w3-bar-item w3-border">
        <button type="submit" class="btn w3-yellow ml-2 w3-bar-item">Search</button>
      </form>
    </div>
</div>

<div class="container mt-5">
    @if (count($posts)>0)
        
    <table class="w3-table-all">
        <tr>
            <th>Post Id</th>
            <th>Post Title</th>
            <th>Category</th>
            <th>Post Thumb</th>
            <th>Post Full Image</th>
            <th>Post Tags</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($posts as $post)
            <tr>
                <td>{{$post['post_id']}}</td>
                <td>{{$post['title']}}</td>
                <td>{{$post['cat_id']}}</td>
                <td><img src="{{asset('imgs/'.$post['thumb'])}}" style='wth:100px;height:100px;' alt=""></td>
                <td><img src="{{asset('imgs/'.$post['full_img'])}}" style='wth:100px;height:100px;' alt=""></td>
                <td>{{$post['tags']}}</td>
                <td><a href="{{'editpost/'.$post['post_id']}}" class="btn w3-green">Edit</a></td>
                <td><a href="{{'deletepost/'.$post['post_id']}}" onclick="return confirm('Are You Sure You want To delete this data')" class="btn w3-red">Delete</a></td>
            </tr>
        @endforeach
    </table>
    @else
    <h2>Not Record Found</h2>
    @endif
    {{-- <?php //echo asset('imgs/')?> --}}
</div>
<div class="container mt-3" style="margin: 0px 40%">
    {{$posts->links()}}

</div>
@include('admin/footer')