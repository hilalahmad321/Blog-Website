@include('admin/header')
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            @foreach ($settings as $setting)
            <form action="{{url('admin/saveupdate/'.$setting['setting_id'])}}" class="p-5" method="post" enctype="multipart/form-data">
                @csrf
                <h1>Setting</h1>
                <div class="form-group">
                    <label for="">Enter logo Name</label>
                    <input type="text" name="logo_name" value="{{$setting['logo_name']}}" id="" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Enter Full Image</label>
                    <input type="file" name="bg_img" id="" class="form-control">
                    <input type="hidden" name="bg_img" value="{{$setting['bg_img']}}">
                    <img src="{{asset('imgs/'.$setting['bg_img'])}}" style="width: 150px;height:150px;" alt="">
                </div>
                <button class="btn w3-blue" type="submit">Add Post</button>
            </form>
@endforeach

        </div>
    </div>
</div>

@include('admin/footer')