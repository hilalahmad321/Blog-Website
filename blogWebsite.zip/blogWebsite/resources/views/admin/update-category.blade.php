@include('admin/header');
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            <form action="{{url('admin/updateCategory/'.$single['cat_id'])}}" class="p-5" method="post">
                @csrf
                <h1>Add Category</h1>
                <div class="form-group">
                    <label for="">Enter Category Name</label>
                    <input type="text" value="{{$single['cat_name']}}" name="cat_name" id="" class="form-control">
                    @error('cat_name')
                        <p class="w3-text-red">{{$message}}</p> 
                    @enderror
                </div>
                <button class="btn w3-blue" type="submit">Add Category</button>
            </form>
        </div>
    </div>
</div>
@include('admin/footer');