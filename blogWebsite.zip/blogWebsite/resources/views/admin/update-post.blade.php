@include('admin/header')
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            @foreach ($single as $sing)
            <form action="{{url('admin/saveupdate/'.$sing['post_id'])}}" class="p-5" method="post" enctype="multipart/form-data">
                @csrf
                <h1>Add Post</h1>
                <div class="form-group">
                    <label for="">Enter Post Title</label>
    
                    <input type="text" value="{{$sing['title']}}" name="title" id="" class="form-control">
                    @error('title')
                    <p class="w3-text-red">{{$message}}</p> 
                 @enderror
                </div>
                <div class="form-group">
                    <label for="">Enter Category</label>
                   <select name="cat_id" class="form-control" id="">
                       <option value="" disabled selected>----Select Any Category----</option>
                       @foreach ($category as $cat)
                       <?php 
                       if($sing['cat_id'] == $cat['cat_id']){
                           $select='selected';
                       }
                       else{
                           $select="";
                       }
                       ?>
                           <option value="{{$cat['cat_id']}}"  <?php echo $select;?>>{{$cat['cat_name']}}</option>
                       @endforeach
                       
                   </select>
                   @error('cat_id')
                   <p class="w3-text-red">{{$message}}</p> 
                @enderror
                </div>
                <div class="form-group">
                    <label for="">Enter Thumb</label>
                    <input type="file" name="thumb" id="" class="form-control">
                    <input type="hidden" name="thumb" value="{{$sing['thumb']}}">
                    <img src="{{asset('imgs/'.$sing['thumb'])}}" style="width: 150px;height:150px;" alt="">
                    @error('thumb')
                    <p class="w3-text-red">{{$message}}</p> 
                 @enderror
                </div>
                <div class="form-group">
                    <label for="">Enter Full Image</label>
                    <input type="file" name="full_img" id="" class="form-control">
                    <input type="hidden" name="full_img" value="{{$sing['full_img']}}">
                    <img src="{{asset('imgs/'.$sing['full_img'])}}" style="width: 150px;height:150px;" alt="">
                    @error('full_img')
                    <p class="w3-text-red">{{$message}}</p> 
                 @enderror
                </div>
                <div class="form-group">
                    <label for="">Enter Detial</label>
                    <textarea name="detail" class="form-control" id="" cols="30" rows="10">{{$sing['detail']}}</textarea>
                    @error('detail')
                    <p class="w3-text-red">{{$message}}</p> 
                 @enderror
                </div>
                <div class="form-group">
                    <label for="">Enter Tags</label>
                    <textarea name="tags" class="form-control" id="" cols="30" rows="4">{{$sing['tags']}}</textarea>
                    @error('tags')
                    <p class="w3-text-red">{{$message}}</p> 
                 @enderror
                </div>
                <button class="btn w3-blue" type="submit">Add Post</button>
            </form>
@endforeach

        </div>
    </div>
</div>

@include('admin/footer')