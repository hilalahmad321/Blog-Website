@include('fortend/header')

<div class="container-fluid background">
    <div class="container w3-text-white">
        <div class="w3-bar" style="padding-top: 30px;">
            <a href="" class="w3-bar-item mb-3 w3-hover-text-white w3-xxlarge" style="text-decoration: none;">Blog Website</a>
            <div class="w3-bar-item w3-right">
                <a href="/" class="w3-bar-item w3-hover-text-yellow">Home</a>
                <a href="{{url('articales')}}" class="w3-bar-item w3-hover-text-yellow">Articales</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Team</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Contact</a>
                @guest
                <a href="{{url('login')}}" class="w3-bar-item w3-hover-text-yellow">login</a>
                <a href="{{url('register')}}" class="w3-bar-item w3-hover-text-yellow">Register</a>
                @else
                <a href="{{url('logout')}}" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();" class="w3-bar-item w3-hover-text-yellow">Logout</a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
                @endguest
            </div>
        </div>
    </div>
    <div class="container mt-5 w3-text-white">
        <h5>Hello ! Welcome to </h5>
        <h1 style="font-size: 4rem;">Blog Website</h1>
      <div class="row">
          <div class="col-md-7">
            <p class="">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque quos perspiciatis facere sit laudantium nobis ad possimus, dolores est ducimus velit rerum tempora facilis temporibus, doloremque autem, quasi quod aperiam?
            </p>
          </div>
      </div>
    </div>
</div>
 <div class="container mt-4">
        <div class="card">
            <div class="car-header p-3 w3-center">
                <a href="" class="w3-large">All category</a> &nbsp; &nbsp; &nbsp; &nbsp;
                @foreach ($categorys as $cat)
                <a href="{{url('articale/'.$cat['cat_id'])}}" class="w3-large">{{$cat['cat_name']}}</a>&nbsp; &nbsp; &nbsp; &nbsp;
                @endforeach
                {{-- <a href="" class="w3-large">All category</a>&nbsp; &nbsp; &nbsp; &nbsp;
                <a href="" class="w3-large">All category</a>&nbsp; &nbsp; &nbsp; &nbsp; --}}
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row">
            @foreach ($posts as $post)
            <div class="col-md-4 mt-2">
                <div class="card">
                    <div class="card-body">
                        <img src="{{asset('imgs/'.$post['thumb'])}}" style="width:300px;height:300px;" alt="">
                        <h1 class="w3-center">{{$post['title']}}</h1>
                    </div>
                    <div class="card-footer w3-center">
                        <a  href="{{url('singlePost/'.$post['post_id'])}}" class="btn w3-blue w3-center">Read More</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    <div class="container pt-4">
        <div class="w3-right">
            {{$posts->links()}}
        </div>
    </div>
@include('fortend/footer')