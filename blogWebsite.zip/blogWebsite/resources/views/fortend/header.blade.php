<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/w3.css')}}">
    <title>Blog Website</title>
</head>
<style>
    .background{
        background:rgba(0, 0, 0, 0.6) url('front/bg_1.jpg');
        background-blend-mode:darken;
        background-repeat: no-repeat;
        background-size: cover;
        width: 100%;
        height: 90vh;
        
    }
</style>
<body>