@include('fortend/header')
<style>
    .background{
        background:rgba(0, 0, 0, 0.6) url('front/bg_1.jpg');
        background-blend-mode:darken;
        background-repeat: no-repeat;
        background-size: cover;
        width: 100%;
        height: 90vh;
        
    }
</style>
<div class="container-fluid background">
    <div class="container w3-text-white">
        <div class="w3-bar" style="padding-top: 30px;">
            <a href="" class="w3-bar-item mb-3 w3-hover-text-white w3-xxlarge" style="text-decoration: none;">Blog Website</a>
            <div class="w3-bar-item w3-right">
                <a href="/" class="w3-bar-item w3-hover-text-yellow">Home</a>
                <a href="{{url('articales')}}" class="w3-bar-item w3-hover-text-yellow">Articales</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Team</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Contact</a>
                @guest
                <a href="{{url('login')}}" class="w3-bar-item w3-hover-text-yellow">login</a>
                <a href="{{url('register')}}" class="w3-bar-item w3-hover-text-yellow">Register</a>
                @else
                <a href="{{url('logout')}}" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();" class="w3-bar-item w3-hover-text-yellow">Logout</a>
                
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
                @endguest
            </div>
        </div>
    </div>
    <div class="container mt-5 w3-text-white">
        <h1 style="font-size: 4rem;">Single Blog</h1>
    </div>
</div>
<div class="container mt-5">
    <div class="row">
       @foreach ($posts as $post)
       <div class="col-md-7">
        <img src="{{asset('imgs/'.$post['full_img'])}}" class='w-100' alt="">
        <h1 class="w3-jumbo">{{$post['title']}}</h1>
        <p>
           {{$post['detail']}}
        </p>
    </div>
       @endforeach
       
        <div class="col-md-5">
            <form action="">
                <input type="text" name="q" id="" placeholder="Search here..." class="form-control">
                <button class="btn w3-blue mt-3" type="submit">Search</button>
            </form>

            <h1>Recent Post</h1>
            <div class="row w3-border p-3">
                @foreach ($limitpost as $limit)
                <div class="col-md-4">
                    <img src="{{asset('imgs/'.$limit['thumb'])}}" class='w-100 mt-3' alt="">
                </div>
                <div class="col-md-8">
                    <h2>{{$limit['title']}} </h2>
                    <a href="{{'/singlePost/'.$limit['post_id']}}" class="btn w3-green">Read More</a>
                </div>
                @endforeach
              
            </div>
        </div>
    </div>
</div>
@auth
<div class="container">
    <div class="card">
        <div class="card-header">
            Comment
        </div>
        <div class="card-body">
            <form action="{{url('save_comment/'.$post["post_id"])}}" method="post">
                @csrf
                <textarea name="comments" id="comment" cols="30" rows="10" class="form-control"></textarea>
                @error('comments')
                   <p class="w3-text-red">{{$message}}</p>
                @enderror
                <button class="btn w3-yellow mt-3">Submit comment</button>
            </form>
        </div>
    </div>
</div>  
@endauth

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            Comments
            <span class="badge badge-dark">{{count($comments)}}</span>
        </div>
        @foreach ($comments as $comment)
        <div class="card-body">
            {{$comment['comments']}}
            <h6>{{$comment['name']}}</h6>
        </div>
        <hr>
        @endforeach
       
    </div>
</div>

@include('fortend/footer')