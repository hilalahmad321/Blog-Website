<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ForntController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\SettingController;
use App\Models\category;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
// Admin route
Route::get('/admin/login',[AdminController::class,'index']);
Route::post('/admin/login',[AdminController::class,'submit_login']);

// dashborad route
Route::get('/admin/dashboard',[AdminController::class,'dashboard']);

// logout

Route::get('/admin/logout',[AdminController::class,'logout']);

// category
Route::get('/admin/category',[CategoryController::class,'index']);
Route::post('/admin/addCategory',[CategoryController::class,'addCategory']);
// Route::get('/admin/search',[CategoryController::class,'searchCategory']);
Route::get('/admin/delete/{cat_id}',[CategoryController::class,'deleteCategory']);
Route::get('/admin/edit/{cat_id}',[CategoryController::class,'updateCategory']);
Route::post('/admin/updateCategory/{cat_id}',[CategoryController::class,'saveUpdateCat']);

// post 
Route::get('/admin/post',[PostController::class ,'index']);
Route::post('/admin/addPost',[PostController::class,'addPost']);
Route::get('/admin/deletepost/{post_id}',[PostController::class,'deletePost']);
Route::get('/admin/editpost/{post_id}',[PostController::class,'editPost']);
Route::post('/admin/saveupdate/{post_id}',[PostController::class,'saveupdatepost']);

// setting
Route::get('/admin/setting',[SettingController::class,'index']);  
Route::post('/admin/saveupdate/{id}',[SettingController::class,'saveupdate']);  
// Frontend 
Route::get('/',[ForntController::class,'index']);
Route::get('/articales',[ForntController::class,'articales']);
Route::get('/articale/{cat_id}',[ForntController::class,'articale']);
Route::get('/singlePost/{post_id}',[ForntController::class,'singlePost']);

Auth::routes();

Route::get('/fortend/home', [App\Http\Controllers\HomeController::class, 'index'])->name('/');
// Save comment


Route::post('/save_comment/{post_id}',[ForntController::class,'save_comment']);
