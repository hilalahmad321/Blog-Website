<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="container mt-4">
          <div class="card">
              <div class="card-header">Dashboard / overview</div>
          </div>
      </div>
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="w3-card-4 w3-blue p-4">
                        <span  class="w3-xlarge">Category</span>
                        <span class="w3-xlarge w3-right">44</span>
                        <hr>
                        <a>View</a>
                        <a class="w3-right">></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="w3-card-4 w3-blue p-4">
                        <span  class="w3-xlarge">Category</span>
                        <span class="w3-xlarge w3-right">44</span>
                        <hr>
                        <a>View</a>
                        <a class="w3-right">></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="w3-card-4 w3-blue p-4">
                        <span  class="w3-xlarge">Category</span>
                        <span class="w3-xlarge w3-right">44</span>
                        <hr>
                        <a>View</a>
                        <a class="w3-right">></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="w3-card-4 w3-blue p-4">
                        <span  class="w3-xlarge">Category</span>
                        <span class="w3-xlarge w3-right">44</span>
                        <hr>
                        <a>View</a>
                        <a class="w3-right">></a>
                    </div>
                </div>
            </div>
        </div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>