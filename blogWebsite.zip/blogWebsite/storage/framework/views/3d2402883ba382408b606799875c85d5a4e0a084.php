<?php echo $__env->make('fortend/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid background">
    <div class="container w3-text-white">
        <div class="w3-bar" style="padding-top: 30px;">
            <a href="" class="w3-bar-item mb-3 w3-hover-text-white w3-xxlarge" style="text-decoration: none;">Blog Website</a>
            <div class="w3-bar-item w3-right">
                <a href="/" class="w3-bar-item w3-hover-text-yellow">Home</a>
                <a href="<?php echo e(url('articales')); ?>" class="w3-bar-item w3-hover-text-yellow">Articales</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Team</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Contact</a>
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(url('login')); ?>" class="w3-bar-item w3-hover-text-yellow">login</a>
                <a href="<?php echo e(url('register')); ?>" class="w3-bar-item w3-hover-text-yellow">Register</a>
                <?php else: ?>
                <a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();" class="w3-bar-item w3-hover-text-yellow">Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="container mt-5 w3-text-white">
        <h5>Hello ! Welcome to </h5>
        <h1 style="font-size: 4rem;">Blog Website</h1>
      <div class="row">
          <div class="col-md-7">
            <p class="">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque quos perspiciatis facere sit laudantium nobis ad possimus, dolores est ducimus velit rerum tempora facilis temporibus, doloremque autem, quasi quod aperiam?
            </p>
          </div>
      </div>
    </div>
</div>
 <div class="container mt-4">
        <div class="card">
            <div class="car-header p-3 w3-center">
                <a href="<?php echo e(url('articales')); ?>" class="w3-large">All category</a> &nbsp; &nbsp; &nbsp; &nbsp;
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('articale/'.$cat['cat_id'])); ?>" class="w3-large"><?php echo e($cat['cat_name']); ?></a>&nbsp; &nbsp; &nbsp; &nbsp;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mt-2">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e(asset('imgs/'.$post['thumb'])); ?>" style="width:300px;height:300px;" alt="">
                        <h1 class="w3-center"><?php echo e($post['title']); ?></h1>
                    </div>
                    <div class="card-footer w3-center">
                        <a  href="<?php echo e(url('singlePost/'.$post['post_id'])); ?>" class="btn w3-blue w3-center">Read More</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container pt-4">
        <div class="w3-right">
            
        </div>
    </div>
<?php echo $__env->make('fortend/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/fortend/category.blade.php ENDPATH**/ ?>