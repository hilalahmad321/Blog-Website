<footer>
    <div class="container-fluid w3-gray">
        <div class="container">
            <div class="row mt-5 pt-5">
                <div class="col-md-4">
                    <h1>Blog Website</h1>
                    <p class="pt-3">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt laborum itaque optio perspiciatis reiciendis necessitatibus, est quod eveniet facere? Neque minus repellat eaque enim? Non suscipit esse animi rem quasi.
                    </p>
              </div>
              <div class="col-md-4">
                  <h1>Information</h1>
                  <div class="w3-bar-block">
                      <a href="<?php echo e(url('/')); ?>" class="w3-bar-item w3-large"> > Home</a>
                      <a href="<?php echo e(url('articales')); ?>" class="w3-bar-item w3-large"> > Article</a>
                      <a href="<?php echo e(url('/')); ?>" class="w3-bar-item w3-large"> > Team</a>
                      <a href="<?php echo e(url('/')); ?>" class="w3-bar-item w3-large"> > Contact</a>
                      <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(url('login')); ?>" class="w3-bar-item w3-large w3-hover-text-yellow"> > login</a>
                    <a href="<?php echo e(url('register')); ?>" class="w3-bar-item w3-large w3-hover-text-yellow"> > Register</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();" class="w3-bar-item w3-large "> > Logout</a>
                    
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php endif; ?>
                  </div>
              </div>
              <div class="col-md-4">
                  <h1>Subscribe</h1>
                  <form action="">
                      <input type="text" name="subscribe" id="" class="form-control">
                      <button class="w3-blue btn mt-3">Subscribe</button>
                  </form>
              </div>
        </div>
    </div>
            <h4 class="w3-center pb-3">@ Copywrite all resverd Powered by Hilal ahmad</h4>
    </div>
</footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/fortend/footer.blade.php ENDPATH**/ ?>