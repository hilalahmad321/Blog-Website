<?php echo $__env->make('fortend/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .background{
        background:rgba(0, 0, 0, 0.6) url('front/bg_1.jpg');
        background-blend-mode:darken;
        background-repeat: no-repeat;
        background-size: cover;
        width: 100%;
        height: 90vh;
        
    }
</style>
<div class="container-fluid background">
    <div class="container w3-text-white">
        <div class="w3-bar" style="padding-top: 30px;">
            <a href="" class="w3-bar-item mb-3 w3-hover-text-white w3-xxlarge" style="text-decoration: none;">Blog Website</a>
            <div class="w3-bar-item w3-right">
                <a href="/" class="w3-bar-item w3-hover-text-yellow">Home</a>
                <a href="<?php echo e(url('articales')); ?>" class="w3-bar-item w3-hover-text-yellow">Articales</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Team</a>
                <a href="" class="w3-bar-item w3-hover-text-yellow">Contact</a>
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(url('login')); ?>" class="w3-bar-item w3-hover-text-yellow">login</a>
                <a href="<?php echo e(url('register')); ?>" class="w3-bar-item w3-hover-text-yellow">Register</a>
                <?php else: ?>
                <a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();" class="w3-bar-item w3-hover-text-yellow">Logout</a>
                
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="container mt-5 w3-text-white">
        <h1 style="font-size: 4rem;">Single Blog</h1>
    </div>
</div>
<div class="container mt-5">
    <div class="row">
       <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-md-7">
        <img src="<?php echo e(asset('imgs/'.$post['full_img'])); ?>" class='w-100' alt="">
        <h1 class="w3-jumbo"><?php echo e($post['title']); ?></h1>
        <p>
           <?php echo e($post['detail']); ?>

        </p>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        <div class="col-md-5">
            <form action="">
                <input type="text" name="q" id="" placeholder="Search here..." class="form-control">
                <button class="btn w3-blue mt-3" type="submit">Search</button>
            </form>

            <h1>Recent Post</h1>
            <div class="row w3-border p-3">
                <?php $__currentLoopData = $limitpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <img src="<?php echo e(asset('imgs/'.$limit['thumb'])); ?>" class='w-100 mt-3' alt="">
                </div>
                <div class="col-md-8">
                    <h2><?php echo e($limit['title']); ?> </h2>
                    <a href="<?php echo e('/singlePost/'.$limit['post_id']); ?>" class="btn w3-green">Read More</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
        </div>
    </div>
</div>
<?php if(auth()->guard()->check()): ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            Comment
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('save_comment/'.$post["post_id"])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <textarea name="comments" id="comment" cols="30" rows="10" class="form-control"></textarea>
                <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p class="w3-text-red"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="btn w3-yellow mt-3">Submit comment</button>
            </form>
        </div>
    </div>
</div>  
<?php endif; ?>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            Comments
            <span class="badge badge-dark"><?php echo e(count($comments)); ?></span>
        </div>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-body">
            <?php echo e($comment['comments']); ?>

            <h6><?php echo e($comment['name']); ?></h6>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
</div>

<?php echo $__env->make('fortend/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/fortend/singlePost.blade.php ENDPATH**/ ?>