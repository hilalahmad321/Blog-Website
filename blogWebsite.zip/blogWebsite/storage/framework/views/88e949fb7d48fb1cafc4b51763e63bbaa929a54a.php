<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            <form action="<?php echo e(url('admin/updateCategory/'.$single['cat_id'])); ?>" class="p-5" method="post">
                <?php echo csrf_field(); ?>
                <h1>Add Category</h1>
                <div class="form-group">
                    <label for="">Enter Category Name</label>
                    <input type="text" value="<?php echo e($single['cat_name']); ?>" name="cat_name" id="" class="form-control">
                </div>
                <button class="btn w3-blue" type="submit">Add Category</button>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/update-category.blade.php ENDPATH**/ ?>