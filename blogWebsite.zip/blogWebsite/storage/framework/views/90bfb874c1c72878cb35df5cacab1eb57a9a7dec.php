<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/w3.css')); ?>">
    <title>Admin | Login</title>
</head>
<style>
    body{
        background-color: crimson
    }
</style>
<?php if(Session::has('adminData')): ?>
<script>
    window.location.href=('dashboard');
</script>
<?php endif; ?>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 w3-content mt-5">
                <div class="w3-card-4 p-4 w3-round-xlarge w3-blue mt-5">
                   
                    <form action="login" method="POST">
                        <?php echo csrf_field(); ?>
                        <h1>Admin Login</h1>
                        <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="w3-text-red w3-xlarge"><?php echo e($err); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <p class="w3-text-red"><?php echo e(session('error')); ?></p>
                    <?php endif; ?>
                        <div class="form-group">
                            <label for=""><b> Enter User Name</b></label>
                            <input type="text" name="username" id="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for=""><b> Enter Password</b></label>
                            <input type="text" name="passwrd" id="" class="form-control">
                        </div>
                        <button class="btn w3-green" type="submit">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/login.blade.php ENDPATH**/ ?>