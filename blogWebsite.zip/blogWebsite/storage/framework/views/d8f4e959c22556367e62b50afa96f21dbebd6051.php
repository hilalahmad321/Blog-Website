<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            <?php $__currentLoopData = $single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(url('admin/saveupdate/'.$sing['post_id'])); ?>" class="p-5" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h1>Add Post</h1>
                <div class="form-group">
                    <label for="">Enter Post Title</label>
    
                    <input type="text" value="<?php echo e($sing['title']); ?>" name="title" id="" class="form-control">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="w3-text-red"><?php echo e($message); ?></p> 
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Category</label>
                   <select name="cat_id" class="form-control" id="">
                       <option value="" disabled selected>----Select Any Category----</option>
                       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php 
                       if($sing['cat_id'] == $cat['cat_id']){
                           $select='selected';
                       }
                       else{
                           $select="";
                       }
                       ?>
                           <option value="<?php echo e($cat['cat_id']); ?>"  <?php echo $select;?>><?php echo e($cat['cat_name']); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                   </select>
                   <?php $__errorArgs = ['cat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p class="w3-text-red"><?php echo e($message); ?></p> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Thumb</label>
                    <input type="file" name="thumb" id="" class="form-control">
                    <input type="hidden" name="thumb" value="<?php echo e($sing['thumb']); ?>">
                    <img src="<?php echo e(asset('imgs/'.$sing['thumb'])); ?>" style="width: 150px;height:150px;" alt="">
                    <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="w3-text-red"><?php echo e($message); ?></p> 
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Full Image</label>
                    <input type="file" name="full_img" id="" class="form-control">
                    <input type="hidden" name="full_img" value="<?php echo e($sing['full_img']); ?>">
                    <img src="<?php echo e(asset('imgs/'.$sing['full_img'])); ?>" style="width: 150px;height:150px;" alt="">
                    <?php $__errorArgs = ['full_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="w3-text-red"><?php echo e($message); ?></p> 
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Detial</label>
                    <textarea name="detail" class="form-control" id="" cols="30" rows="10"><?php echo e($sing['detail']); ?></textarea>
                    <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="w3-text-red"><?php echo e($message); ?></p> 
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Tags</label>
                    <textarea name="tags" class="form-control" id="" cols="30" rows="4"><?php echo e($sing['tags']); ?></textarea>
                    <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="w3-text-red"><?php echo e($message); ?></p> 
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="btn w3-blue" type="submit">Add Post</button>
            </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<pre>

</pre>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/update-post.blade.php ENDPATH**/ ?>