<?php echo $__env->make('fortend/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid background">
        <div class="container w3-text-white">
            <div class="w3-bar" style="padding-top: 30px;">
                <a href="" class="w3-bar-item mb-3 w3-hover-text-white w3-xxlarge" style="text-decoration: none;">Blog Website</a>
                <div class="w3-bar-item w3-right">
                    <a href="/" class="w3-bar-item w3-hover-text-yellow">Home</a>
                    <a href="articales" class="w3-bar-item w3-hover-text-yellow">Articales</a>
                    <a href="" class="w3-bar-item w3-hover-text-yellow">Team</a>
                    <a href="" class="w3-bar-item w3-hover-text-yellow">Contact</a>
                    <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(url('login')); ?>" class="w3-bar-item w3-hover-text-yellow">login</a>
                    <a href="<?php echo e(url('register')); ?>" class="w3-bar-item w3-hover-text-yellow">Register</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();" class="w3-bar-item w3-hover-text-yellow">Logout</a>
                    
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="container mt-5 w3-text-white">
            <h5>Hello ! Welcome to </h5>
            <h1 style="font-size: 4rem;">Blog Website</h1>
          <div class="row">
              <div class="col-md-7">
                <p class="">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque quos perspiciatis facere sit laudantium nobis ad possimus, dolores est ducimus velit rerum tempora facilis temporibus, doloremque autem, quasi quod aperiam?
                </p>
              </div>
          </div>
        </div>
    </div>
   
    <div class="container mt-5">
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mt-4">
                <img class="w-100" src="<?php echo e(asset('imgs/'.$post['thumb'])); ?>" style="width: 500px;height:350px;" class="img-thumbnail" alt="">
            </div>
            <div class="col-md-6">
                <h1 class="w3-jumbo"><?php echo e($post['title']); ?></h1>
                <p class="mt-4">
                   <?php echo substr($post['detail'],0,300)."......."?>
                </p>
                <a href="<?php echo e('singlePost/'.$post['post_id']); ?>" class="btn w3-light-blue mt-5">Read More..</a>
                <h4>Views <?php echo e($post['views']); ?></h4>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container ">
        <div class="w3-right">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
    <?php echo $__env->make('fortend/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/fortend/index.blade.php ENDPATH**/ ?>