<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            Category \ View
        </div>
    </div>
</div>
<?php if(Session::has('success')): ?>
<div class="container">
    <div class="w3-panel w3-green w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Success!</h3>
        <p><?php echo e(session('success')); ?></p>
      </div>
</div>
<?php endif; ?>
<?php if(Session::has('delete')): ?>
<div class="container">
    <div class="w3-panel w3-yellow w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Warning!</h3>
        <p><?php echo e(session('delete')); ?></p>
      </div>
</div>
<?php endif; ?>

<div class="container mt-3">
    <div class="card p-3">
        <div >
            Category ( <?php echo e(count($total)); ?> )
            <button class="w3-right btn w3-blue" onclick="document.getElementById('id01').style.display='block'">Add Category</button>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content w3-animate-right">
                    <form action="addCategory" class="p-5" method="post">
                        <?php echo csrf_field(); ?>
                        <span onclick="document.getElementById('id01').style.display='none'" class="w3-display-topright btn w3-red mt-2 mr-2">X</span>
                        <h1>Add Category</h1>
                        <div class="form-group">
                            <label for="">Enter Category Name</label>
                            <input type="text" name="cat_name" id="" class="form-control">
                            <?php $__errorArgs = ['cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn w3-blue" type="submit">Add Category</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">
    <div class="w3-bar">
      <form action="search" method="POST">
        <input type="text" name="search" id="" class="form-control w3-bar-item w3-border">
        <button type="submit" class="btn w3-yellow ml-2 w3-bar-item">Search</button>
      </form>
    </div>
</div>

<div class="container mt-5">
    <table class="w3-table-all">
        <tr>
            <th>Category Id</th>
            <th>Category Name</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cat['cat_id']); ?></td>
                <td><?php echo e($cat['cat_name']); ?></td>
                <td><a href="<?php echo e('edit/'.$cat['cat_id']); ?>" class="btn w3-green">Edit</a></td>
                <td><a href="<?php echo e('delete/'.$cat['cat_id']); ?>" onclick="return confirm('Are You Sure You want To delete this data')" class="btn w3-red">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div class="container mt-3" style="margin: 0px 40%">
    <?php echo e($categorys->links()); ?>


</div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/category.blade.php ENDPATH**/ ?>