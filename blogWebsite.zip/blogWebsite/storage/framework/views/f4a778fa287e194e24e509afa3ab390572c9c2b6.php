<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(url('admin/saveupdate/'.$setting['setting_id'])); ?>" class="p-5" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h1>Setting</h1>
                <div class="form-group">
                    <label for="">Enter logo Name</label>
                    <input type="text" name="logo_name" value="<?php echo e($setting['logo_name']); ?>" id="" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Enter Full Image</label>
                    <input type="file" name="bg_img" id="" class="form-control">
                    <input type="hidden" name="bg_img" value="<?php echo e($setting['bg_img']); ?>">
                    <img src="<?php echo e(asset('imgs/'.$setting['bg_img'])); ?>" style="width: 150px;height:150px;" alt="">
                </div>
                <button class="btn w3-blue" type="submit">Add Post</button>
            </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>

<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/setting.blade.php ENDPATH**/ ?>