<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            Post \ View
        </div>
    </div>
</div>
<?php if(Session::has('success')): ?>
<div class="container">
    <div class="w3-panel w3-green w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Success!</h3>
        <p><?php echo e(session('success')); ?></p>
      </div>
</div>
<?php endif; ?>
<?php if(Session::has('delete')): ?>
<div class="container">
    <div class="w3-panel w3-yellow w3-display-container" >
        <span onclick="this.parentElement.style.display='none'"
        class="w3-button w3-large w3-display-topright">&times;</span>
        <h3>Warning!</h3>
        <p><?php echo e(session('delete')); ?></p>
      </div>
</div>
<?php endif; ?>

<div class="container mt-3">
    <div class="card p-3">
        <div >
            Category ( <?php echo e(count($total)); ?> )
            <button class="w3-right btn w3-blue" onclick="document.getElementById('id01').style.display='block'">Add Post</button>
        </div>
    </div>
</div>
<div class="container" style="z-index:10;">
    <div class="row">
        <div class="col-md-6">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content w3-animate-right">
                    <form action="addPost" class="p-5" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <span onclick="document.getElementById('id01').style.display='none'" class="w3-display-topright btn w3-red mt-2 mr-2">X</span>
                        <h1>Add Post</h1>
                        <div class="form-group">
                            <label for="">Enter Post Title</label>
                            <input type="text" name="title" id="" class="form-control">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Category</label>
                           <select name="cat_id" class="form-control" id="">
                               <option value="" disabled selected>----Select Any Category----</option>
                               <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($cat['cat_id']); ?>"><?php echo e($cat['cat_name']); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <?php $__errorArgs = ['cat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Thumb</label>
                            <input type="file" name="thumb" id="" class="form-control">
                            <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Full Image</label>
                            <input type="file" name="full_img" id="" class="form-control">
                            <?php $__errorArgs = ['full_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Detial</label>
                            <textarea name="detail" class="form-control" id="" cols="30" rows="10"></textarea>
                            <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="form-group">
                            <label for="">Enter Tags</label>
                            <textarea name="tags" class="form-control" id="" cols="30" rows="4"></textarea>
                            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <p class="w3-text-red"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn w3-blue" type="submit">Add Post</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">
    <div class="w3-bar">
      <form action="search" method="POST">
        <input type="text" name="search" id="" class="form-control w3-bar-item w3-border">
        <button type="submit" class="btn w3-yellow ml-2 w3-bar-item">Search</button>
      </form>
    </div>
</div>

<div class="container mt-5">
    <?php if(count($posts)>0): ?>
        
    <table class="w3-table-all">
        <tr>
            <th>Post Id</th>
            <th>Post Title</th>
            <th>Category</th>
            <th>Post Thumb</th>
            <th>Post Full Image</th>
            <th>Post Tags</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($post['post_id']); ?></td>
                <td><?php echo e($post['title']); ?></td>
                <td><?php echo e($post['cat_id']); ?></td>
                <td><img src="<?php echo e(asset('imgs/'.$post['thumb'])); ?>" style='wth:100px;height:100px;' alt=""></td>
                <td><img src="<?php echo e(asset('imgs/'.$post['full_img'])); ?>" style='wth:100px;height:100px;' alt=""></td>
                <td><?php echo e($post['tags']); ?></td>
                <td><a href="<?php echo e('editpost/'.$post['post_id']); ?>" class="btn w3-green">Edit</a></td>
                <td><a href="<?php echo e('deletepost/'.$post['post_id']); ?>" onclick="return confirm('Are You Sure You want To delete this data')" class="btn w3-red">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    <h2>Not Record Found</h2>
    <?php endif; ?>
    
</div>
<div class="container mt-3" style="margin: 0px 40%">
    <?php echo e($posts->links()); ?>


</div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogWebsite\resources\views/admin/post.blade.php ENDPATH**/ ?>